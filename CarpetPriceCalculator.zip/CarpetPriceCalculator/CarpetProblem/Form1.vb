﻿Public Class Form1
    Dim tenpercent1 As Decimal
    Dim tenpercent2 As Decimal
    Dim tenpercent3 As Decimal
    Dim tenpercent4 As Decimal
    Dim tenpercent5 As Decimal
    Dim totalarea As Decimal

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        totalarea = TextBox3.Text
        Label16.Text = totalarea * 2.99

        If RadioButton1.Checked = True Then
            CheckBox1.Visible = True
            Label8.Visible = True
            CheckBox6.Visible = True
            Label17.Visible = True
            Label16.Visible = True
            Label25.Visible = True
        End If

        If RadioButton1.Checked = False Then
            CheckBox1.Checked = False
            CheckBox6.Checked = False
            CheckBox1.Visible = False
            Label8.Visible = False
            CheckBox6.Visible = False
            Label17.Visible = False
        End If

        Label16.Text = FormatCurrency(Label16.Text, 2)
        Label18.Text = FormatCurrency(Val(Label18.Text), 2)

    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        totalarea = TextBox3.Text
        Label16.Text = totalarea * 5.99

        If RadioButton2.Checked = True Then
            CheckBox2.Visible = True
            Label9.Visible = True
            CheckBox7.Visible = True
            Label20.Visible = True
            Label16.Visible = True
            Label25.Visible = True
        End If

        If RadioButton2.Checked = False Then
            CheckBox2.Checked = False
            CheckBox7.Checked = False
            CheckBox2.Visible = False
            CheckBox7.Visible = False
            Label20.Visible = False
            Label9.Visible = False
        End If

        Label16.Text = FormatCurrency(Label16.Text, 2)
        Label18.Text = FormatCurrency(Val(Label18.Text), 2)

    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        totalarea = TextBox3.Text
        Label16.Text = totalarea * 4.99

        If RadioButton3.Checked = True Then
            CheckBox3.Visible = True
            Label10.Visible = True
            CheckBox8.Visible = True
            Label21.Visible = True
            Label16.Visible = True
            Label25.Visible = True
        End If

        If RadioButton3.Checked = False Then
            CheckBox3.Checked = False
            CheckBox8.Checked = False
            CheckBox3.Visible = False
            CheckBox8.Visible = False
            Label21.Visible = False
            Label10.Visible = False
        End If

        Label16.Text = FormatCurrency(Label16.Text, 2)
        Label18.Text = FormatCurrency(Val(Label18.Text), 2)

    End Sub

    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton4.CheckedChanged
        totalarea = TextBox3.Text
        Label16.Text = totalarea * 6.99

        If RadioButton4.Checked = True Then
            CheckBox4.Visible = True
            Label11.Visible = True
            CheckBox9.Visible = True
            Label22.Visible = True
            Label16.Visible = True
            Label25.Visible = True
        End If

        If RadioButton4.Checked = False Then
            CheckBox4.Checked = False
            CheckBox9.Checked = False
            CheckBox4.Visible = False
            CheckBox9.Visible = False
            Label22.Visible = False
            Label11.Visible = False
        End If

        Label16.Text = FormatCurrency(Label16.Text, 2)
        Label18.Text = FormatCurrency(Val(Label18.Text), 2)

    End Sub

    Private Sub RadioButton5_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton5.CheckedChanged
        totalarea = TextBox3.Text
        Label16.Text = totalarea * 7.5

        If RadioButton5.Checked = True Then
            CheckBox5.Visible = True
            Label12.Visible = True
            CheckBox10.Visible = True
            Label23.Visible = True
            Label16.Visible = True
            Label25.Visible = True
        End If

        If RadioButton5.Checked = False Then
            CheckBox5.Checked = False
            CheckBox10.Checked = False
            CheckBox5.Visible = False
            CheckBox10.Visible = False
            Label23.Visible = False
            Label12.Visible = False
        End If

        Label16.Text = FormatCurrency(Label16.Text, 2)
        Label18.Text = FormatCurrency(Val(Label18.Text), 2)

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        TextBox3.Text = Val(TextBox1.Text) * Val(TextBox2.Text)
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        TextBox3.Text = Val(TextBox1.Text) * Val(TextBox2.Text)
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox1.Text = ""
        TextBox2.Text = ""
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            Label16.Text = Label16.Text + 25
            Label26.Visible = True
        Else
            Label16.Text = Label16.Text - 25
            Label26.Visible = False
        End If

        Label16.Text = FormatCurrency(Label16.Text, 2)
    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged

        If CheckBox2.Checked = True Then
            Label16.Text = Label16.Text + 25
            Label26.Visible = True
        Else
            Label16.Text = Label16.Text - 25
            Label26.Visible = False
        End If

        Label16.Text = FormatCurrency(Label16.Text, 2)
    End Sub

    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked = True Then
            Label16.Text = Label16.Text + 25
            Label26.Visible = True
        Else
            Label16.Text = Label16.Text - 25
            Label26.Visible = False
        End If

        Label16.Text = FormatCurrency(Label16.Text, 2)
    End Sub

    Private Sub CheckBox4_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox4.CheckedChanged
        If CheckBox4.Checked = True Then
            Label16.Text = Label16.Text + 25
            Label26.Visible = True
        Else
            Label16.Text = Label16.Text - 25
            Label26.Visible = False
        End If

        Label16.Text = FormatCurrency(Label16.Text, 2)
    End Sub

    Private Sub CheckBox5_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox5.CheckedChanged
        If CheckBox5.Checked = True Then
            Label16.Text = Label16.Text + 25
            Label26.Visible = True
        Else
            Label16.Text = Label16.Text - 25
            Label26.Visible = False
        End If

        Label16.Text = FormatCurrency(Label16.Text, 2)
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        If ListBox1.Text = "Red" Then
            PictureBox1.BackColor = Color.Red
        End If

        If ListBox1.Text = "Orange" Then
            PictureBox1.BackColor = Color.Orange
        End If

        If ListBox1.Text = "Yellow" Then
            PictureBox1.BackColor = Color.Yellow
        End If

        If ListBox1.Text = "Green" Then
            PictureBox1.BackColor = Color.Green
        End If

        If ListBox1.Text = "Blue" Then
            PictureBox1.BackColor = Color.Blue
        End If

        If ListBox1.Text = "White" Then
            PictureBox1.BackColor = Color.White
        End If

        If ListBox1.Text = "Grey" Then
            PictureBox1.BackColor = Color.Gray
        End If


    End Sub

    Private Sub CheckBox6_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox6.CheckedChanged
        Label18.Visible = True
        Label24.Visible = True
        tenpercent1 = (totalarea * 2.99) / 10
        Label18.Text = tenpercent1

        If CheckBox6.Checked = True Then
            Label16.Text = Label16.Text + tenpercent1
        Else
            Label16.Text = Label16.Text - Label18.Text
            Label18.Visible = False
            Label24.Visible = False
        End If

        Label16.Text = FormatCurrency(Label16.Text, 2)
        Label18.Text = FormatCurrency(Label18.Text, 2)
    End Sub

    Private Sub CheckBox7_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox7.CheckedChanged
        Label18.Visible = True
        Label24.Visible = True
        tenpercent2 = (totalarea * 5.99) / 10
        Label18.Text = tenpercent2

        If CheckBox7.Checked = True Then
            Label16.Text = Label16.Text + tenpercent2
        Else
            Label16.Text = Label16.Text - Label18.Text
            Label18.Visible = False
            Label24.Visible = False
        End If

        Label16.Text = FormatCurrency(Label16.Text, 2)
        Label18.Text = FormatCurrency(Label18.Text, 2)
    End Sub

    Private Sub CheckBox8_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox8.CheckedChanged
        Label18.Visible = True
        Label24.Visible = True
        tenpercent3 = (totalarea * 4.99) / 10
        Label18.Text = tenpercent3

        If CheckBox8.Checked = True Then
            Label16.Text = Label16.Text + tenpercent3
        Else
            Label16.Text = Label16.Text - Label18.Text
            Label18.Visible = False
            Label24.Visible = False
        End If

        Label16.Text = FormatCurrency(Label16.Text, 2)
        Label18.Text = FormatCurrency(Label18.Text, 2)
    End Sub

    Private Sub CheckBox9_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox9.CheckedChanged
        Label18.Visible = True
        Label24.Visible = True
        tenpercent4 = (totalarea * 6.99) / 10
        Label18.Text = tenpercent4

        If CheckBox9.Checked = True Then
            Label16.Text = Label16.Text + tenpercent4
        Else
            Label16.Text = Label16.Text - Label18.Text
            Label18.Visible = False
            Label24.Visible = False
        End If

        Label16.Text = FormatCurrency(Label16.Text, 2)
        Label18.Text = FormatCurrency(Label18.Text, 2)
    End Sub

    Private Sub CheckBox10_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox10.CheckedChanged
        Label18.Visible = True
        Label24.Visible = True
        tenpercent5 = (totalarea * 7.5) / 10
        Label18.Text = tenpercent5

        If CheckBox10.Checked = True Then
            Label16.Text = Label16.Text + tenpercent5
        Else
            Label16.Text = Label16.Text - Label18.Text
            Label18.Visible = False
            Label24.Visible = False
        End If

        Label16.Text = FormatCurrency(Label16.Text, 2)
        Label18.Text = FormatCurrency(Label18.Text, 2)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Label13.Text = "ft"
        Label14.Text = "ft"
        Label19.Text = "ft²"
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Label13.Text = "metres"
        Label14.Text = "metres"
        Label19.Text = "metres²"
    End Sub
End Class
